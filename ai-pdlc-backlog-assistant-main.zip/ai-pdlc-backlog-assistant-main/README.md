# Backlog Assistant 🚀

An agentic AI system designed to transform raw requirement specifications into a structured project hierarchy: **Dragonboat Features** → **Jira Epics** → **Jira Stories**.

## 📖 Overview

The Backlog Assistant solves the manual overhead of requirement decomposition. It uses **GPT-4o** and **LangGraph** to automate the creation of backlog items while maintaining a **Human-in-the-Loop (HITL)** approval process at every critical stage.

### Key Features
- **Requirement Transformation**: Spec → Feature → Epic → Story.
- **AI Critic**: Built-in self-correction loop to validate Gherkin AC and standards before human review.
- **Hardened Security**: Backend-managed token storage (Encrypted PG + Vault).
- **Hybrid Search (RAG)**: Retrieves team conventions and historical context from Azure AI Search.

---

## 🏗️ Architecture Documentation

The project includes a comprehensive set of **PlantUML** diagrams located in `docs/architecture/`.

### How to use the Diagrams
1.  **Rendering**: Use the [PlantUML Extension](https://marketplace.visualstudio.com/items?itemName=jebbs.plantuml) for VS Code or the [PlantUML Online Server](https://www.plantuml.com/plantuml/).
2.  **Standardized Syntax**: All labels are hardened (quoted/standardized) to ensure visibility in all renderers.
3.  **Core Maps**:
    - [System Context](docs/architecture/c4/c4-1-context.puml): High-level ecosystem.
    - [Container Architecture](docs/architecture/c4/c4-2-container.puml): Services and storage relationships.
    - [State Machine](docs/architecture/statemachine/langgraph.puml): The LangGraph logic and self-critique loops.
    - [Transformation Sequence](docs/architecture/sequences/seq-requirement-decomposition.puml): End-to-end spec decomposition flow.

---

## 📁 Directory Structure

```text
ai-pdlc/
├── docs/
│   ├── architecture/        # PlantUML diagrams and technical specs
│   ├── content-templates/   # Standard templates for Epics/Stories
│   └── assets/              # Rendered diagrams and images
├── src/                     # (In progress) Source code
└── README.md                # Project entry point
```

## 🛠️ Tech Stack
- **Language**: Python (FastAPI)
- **AI**: Azure OpenAI (GPT-4o, Ada Embeddings)
- **Orchestration**: LangGraph
- **Data**: PostgreSQL (Flexible Server), Redis Enterprise
- **Search**: Azure AI Search (Vector + Hybrid)
- **Connectivity**: ExpressRoute / VPN Gateway (for On-Premises Jira/Vault)

## 🚀 Getting Started
1.  **Clone the Repo**: `git clone ...`
2.  **Explore Documentation**: Review the [Architecture Walkthrough](docs/architecture/walkthrough.md - *Note: Update path if needed*) or browse the `docs/` folder.
3.  **Future Roadmap**: Check out [Future Considerations](docs/architecture/future-considerations.md) for planned enhancements like PII masking and test scaffolding.
