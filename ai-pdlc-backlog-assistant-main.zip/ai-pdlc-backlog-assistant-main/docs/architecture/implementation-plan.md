# Requirement Transformation Workflow Implementation

This plan outlines the technical steps to implement the core objective: transforming raw requirement specifications into a structured hierarchy of Dragonboat Features and Jira Issues (Epics and Stories).

## Proposed Changes

### [Backlog Service]

#### [MODIFY] [langgraph.puml](statemachine/langgraph.puml)
- Implement the `DecompositionFlow` in LangGraph.
- State nodes: `EF` (Extract Feature), `DE` (Decompose to Epics), `DS` (Decompose to Stories).
- Interrupt nodes for HITL: `HF`, `HE`, `HS`.
- Integrated **AI Critic** loops for automated validation.

#### [NEW] [decomposition_logic.py](../../src/backlog_service/workflows/decomposition.py)
- Logic for multi-stage LLM prompts.
- Stage 1: Spec -> Feature.
- Stage 2: Feature + Spec -> Epics.
- Stage 3: Epic + Spec -> Stories (with AC).

### [AI Critic Logic]

#### [NEW] [critic_prompts.py](../../src/backlog_service/ai/critic_prompts.py)
- **Validation Criteria**:
    - Gherkin Syntax correctness (Given/When/Then).
    - Alignment with Definition of Ready (DoR).
    - Scope consistency (Does the Story match the Epic's goal?).
- **Reflection Loop**: 
    - The Critic provides structured JSON feedback.
    - The Generator adjusts the prompt based on the critique.
    - Max 2 iterations before flagging for human review.

### [External Connectors]

#### [MODIFY] [c4-2-container.puml](c4/c4-2-container.puml)
- Ensure Jira and Dragonboat clients support parent-child linking (Jira Epic Link, Story Parent).
- Maintain custom field mapping for Dragonboat Feature ID inside Jira Epics for cross-platform linking.
- **Token Manager**: Backend-managed OAuth token storage and refresh.

## Verification Plan

### Automated Tests
- Mock LLM responses for a sample PDF/Text spec.
- Verify LangGraph state transitions stop at HITL checkpoints.
- Verify the final payload sent to Jira and Dragonboat preserves the hierarchy.

### Manual Verification
- Trace a requirement from the Chat UI.
- Verify the created Feature in Dragonboat.
- Verify the linked Epics and Stories in Jira.
