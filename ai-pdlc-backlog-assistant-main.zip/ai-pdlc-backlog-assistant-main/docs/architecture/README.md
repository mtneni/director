# Architecture Diagrams

PlantUML diagrams for the AI-Powered Agentic Backlog Assistant.

## Rendering Diagrams

### Option 1: VS Code Extension
Install "PlantUML" extension by jebbs, then right-click any `.puml` file → "Preview Current Diagram"

### Option 2: Command Line
```bash
# Install PlantUML
# Windows: choco install plantuml
# Mac: brew install plantuml

# Render all diagrams
java -jar plantuml.jar -tpng c4/*.puml
java -jar plantuml.jar -tpng sequences/*.puml
java -jar plantuml.jar -tpng deployment/*.puml
```

### Option 3: Online
Visit [plantuml.com](http://www.plantuml.com/plantuml/uml/) and paste diagram content.

## Diagram Index

### C4 Diagrams
| File | Description |
|------|-------------|
| `c4/c4-1-context.puml` | System Context - external actors and systems |
| `c4/c4-2-container-mvp.puml` | Container diagram for MVP scope |
| `c4/c4-2-container-target.puml` | Container diagram for target state |
| `c4/c4-3-langgraph.puml` | Component diagram of LangGraph service |

### Sequence Diagrams
| File | Description |
|------|-------------|
| `sequences/seq-auth-flow.puml` | Multi-token authentication flow |
| `sequences/seq-hitl-approval.puml` | Human-in-the-loop approval process |
| `sequences/seq-story-refinement.puml` | End-to-end story refinement |

### State Machines
| File | Description |
|------|-------------|
| `statemachine/langgraph-mvp.puml` | LangGraph workflow (MVP) |
| `statemachine/langgraph-target.puml` | LangGraph workflow (Target) |

### Deployment
| File | Description |
|------|-------------|
| `deployment/deployment-azure.puml` | Azure AKS deployment topology |
