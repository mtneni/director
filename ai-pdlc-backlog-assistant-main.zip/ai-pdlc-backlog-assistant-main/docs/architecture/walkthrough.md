# Architecture Walkthrough: Backlog Assistant

This document summarizes the current state of the Backlog Assistant architecture, focusing on the core objective of transforming requirement specifications into structured backlog items.

## 1. High-Level Context
The [Context Diagram](c4/c4-1-context.puml) shows how the **Backlog Assistant** serves as the bridge between raw requirements (PM) and the execution backlog (PO/Dev), interacting with **Dragonboat** (Portfolio) and **Jira DC** (Task Management).

## 2. Consolidated Container Architecture
The [Container Diagram](c4/c4-2-container.puml) reflects a hardened, production-ready setup:
- **Asynchronous Processing**: Long-running AI tasks use a polling pattern.
- **Backend Token Management**: Credentials for Jira and Dragonboat are managed server-side for security and resilience.
- **Entity Locking**: Redis is used for distributed locking to prevent state conflicts.

## 3. Core Workflow: Requirement Decomposition
The [Decomposition Sequence](sequences/seq-requirement-decomposition.puml) illustrates the multi-stage transformation:
1. **Feature Extraction**: Raw spec -> Dragonboat Feature.
2. **Bulk Decomposition**: Feature -> Jira Epics -> Jira Stories.
3. **HITL Efficiency**: User reviews the entire hierarchy in a single tree view before atomic execution.

## 4. Agentic State Machine
The [Detailed LangGraph State Machine](statemachine/langgraph.puml) defines the agentic behavior:
- **Parse Intent**: Routes to specific flows (Decomp, Refine, Duplicate, etc.).
- **Feedback Loops**: Every flow supports user feedback to refine results before the final "Apply" state.
- **AI Critic**: Built-in self-correction (Reflection) loop validates output against standards before the user ever sees it.

## 5. Deployment & Security
The [Azure Deployment Diagram](deployment/deployment-azure.puml) includes:
- **Secure Connectivity**: ExpressRoute/VPN Gateway for On-Premises access (Jira, Vault).
- **Hardened Secrets**: HashiCorp Vault for credential rotation.
- **Observability**: Full Datadog integration for APM and Logs.

---
*All diagrams have been refined to use standard label syntax (removing slashes) to ensure consistent rendering across platforms.*

**See Also:** [Future Architecture Considerations](future-considerations.md)
