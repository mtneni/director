# Feature Template

> **Hierarchy**: Feature → Epic → Story
> **Master System**: Dragonboat (synced read-only to Jira DC)

## Required Fields

| Field | Description | Example |
|-------|-------------|---------|
| **Title** | Concise feature name | "Self-Service Password Reset" |
| **Business Outcome** | What problem this solves for users/business | "Reduce helpdesk tickets by 40%" |
| **Target OKR** | Link to Dragonboat OKR | OKR-2024-Q2-03 |
| **Success Metrics** | How we measure success | "Ticket reduction %, User adoption rate" |
| **Target Release** | Planned release/quarter | 2024-Q3 |

## Template

```markdown
## Summary
[1-2 sentence description of the feature]

## Business Outcome
**Problem**: [What problem exists today?]
**Solution**: [How does this feature solve it?]
**Impact**: [Who benefits and how?]

## Success Metrics
- [ ] Metric 1: [description] - Target: [value]
- [ ] Metric 2: [description] - Target: [value]

## Scope
**In Scope**:
- [Capability 1]
- [Capability 2]

**Out of Scope**:
- [Not included 1]
- [Not included 2]

## Dependencies
- [Dependency 1]
- [Dependency 2]

## Risks
| Risk | Impact | Mitigation |
|------|--------|------------|
| [Risk 1] | High/Medium/Low | [Strategy] |

## Child Epics
- [ ] Epic 1: [Title] - [Brief description]
- [ ] Epic 2: [Title] - [Brief description]
```

## AI Assistance Points

| Assistance | When Triggered |
|------------|----------------|
| Suggest metrics | Feature created without success metrics |
| Validate OKR alignment | After OKR link is added |
| Detect scope creep | Epic count exceeds threshold |
| Flag missing dependencies | Cross-feature analysis |
