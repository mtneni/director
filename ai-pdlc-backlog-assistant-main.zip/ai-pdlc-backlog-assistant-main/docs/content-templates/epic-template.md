# Epic Template

> **Hierarchy**: Feature → Epic → Story
> **Master System**: Jira DC

## Required Fields

| Field | Description | Example |
|-------|-------------|---------|
| **Title** | Concise epic name | "Password Reset UI Flow" |
| **Parent Feature** | Link to Dragonboat Feature | FEAT-123 |
| **Scope Boundary** | Clear boundaries of what's included | "UI only, no backend changes" |
| **Definition of Done** | Epic-level completion criteria | "All stories done, QA signed off" |
| **Target Sprint/Release** | When this should complete | PI-2024-3 |

## Template

```markdown
## Summary
[Brief description of the epic and its purpose]

## Parent Feature
**Feature**: [FEAT-XXX - Feature Title]
**Outcome Contribution**: [How this epic contributes to the feature outcome]

## Scope Boundary
**This Epic Includes**:
- [Specific capability 1]
- [Specific capability 2]

**This Epic Does NOT Include**:
- [Excluded item 1 - covered by Epic XXX]
- [Excluded item 2 - out of scope]

## Technical Approach
[High-level technical approach or architecture notes]

## Definition of Done
- [ ] All child stories completed
- [ ] Integration testing passed
- [ ] Documentation updated
- [ ] [Custom criteria]

## Dependencies
| Dependency | Type | Status |
|------------|------|--------|
| [Epic/Story] | Blocks/Blocked by | [Status] |

## Child Stories
- [ ] Story 1: [Title]
- [ ] Story 2: [Title]
```

## AI Assistance Points

| Assistance | When Triggered |
|------------|----------------|
| Generate story breakdown | Epic created, no stories |
| Check Feature alignment | Summary doesn't match Feature outcome |
| Detect overlapping epics | Similar scope to other epics |
| Suggest DoD items | DoD is missing or incomplete |
