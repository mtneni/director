# Story Template

> **Hierarchy**: Feature → Epic → Story
> **Master System**: Jira DC

## Required Fields

| Field | Description | Example |
|-------|-------------|---------|
| **Title** | User story format | "As a user, I want to reset my password via email" |
| **Parent Epic** | Link to parent Epic | EPIC-456 |
| **Acceptance Criteria** | Gherkin format | Given/When/Then scenarios |
| **Story Points** | Effort estimate | 3 |
| **Priority** | MoSCoW or value/effort | Must Have |

## Template

```markdown
## User Story
**As a** [type of user]
**I want** [goal/desire]
**So that** [benefit/value]

## Parent Epic
**Epic**: [EPIC-XXX - Epic Title]

## Acceptance Criteria

### Scenario 1: [Happy path]
```gherkin
Given [initial context]
And [additional context]
When [action performed]
Then [expected outcome]
And [additional outcome]
```

### Scenario 2: [Edge case]
```gherkin
Given [initial context]
When [action performed]
Then [expected outcome]
```

### Scenario 3: [Error handling]
```gherkin
Given [initial context]
When [invalid action performed]
Then [error handling behavior]
```

## Technical Notes
[Optional: Implementation hints, API endpoints, UI mockup links]

## Dependencies
- [Story/Task] - [Blocks/Blocked by]

## Definition of Done
- [ ] Code complete and peer reviewed
- [ ] All acceptance criteria passing
- [ ] Unit tests written (>80% coverage)
- [ ] Integration tests passing
- [ ] Documentation updated (if applicable)
```

## AI Assistance Points

| Assistance | When Triggered |
|------------|----------------|
| Generate Gherkin AC | Story has no AC or vague AC |
| Suggest edge cases | AC only has happy path |
| Check Epic alignment | Story scope exceeds Epic boundary |
| Detect duplicates | Similar to existing stories |
| Suggest story split | Story too large (>8 points) |
| Validate completeness | Missing required fields |

## AI Refinement Example

**Before (vague)**:
```
As a user, I want to reset my password
AC: User can reset password
```

**After (AI refined)**:
```
As a registered user
I want to reset my password via email link
So that I can regain access to my account when I forget my password

### Scenario 1: Successful password reset request
Given I am on the login page
And I click "Forgot Password"
When I enter my registered email "user@example.com"
And I click "Send Reset Link"
Then I should see "Reset link sent to your email"
And I should receive an email within 5 minutes

### Scenario 2: Invalid email
Given I am on the forgot password page
When I enter an unregistered email
And I click "Send Reset Link"
Then I should see "Email not found" error
```
